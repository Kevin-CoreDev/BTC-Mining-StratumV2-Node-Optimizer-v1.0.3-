@echo off
set "base_dir=%~dp0"
cd /d "%base_dir%"
start "" "%~dp0python_env\pythonw.exe" "%~dp0btc_mining.pyc"
exit